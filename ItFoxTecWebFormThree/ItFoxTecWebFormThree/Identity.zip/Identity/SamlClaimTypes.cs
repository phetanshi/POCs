﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ItFoxTecWebFormThree.Identity
{
    public class SamlClaimTypes
    {
        public const string DisplayName = "http://schemas.microsoft.com/identity/claims/displayname";
    }
}